const $=id=>document.getElementById(id);
const STORAGE_KEY='bolita-data-v1';
const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
const money=n=>'$'+Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const load=()=>{try{return JSON.parse(localStorage.getItem(STORAGE_KEY))||{people:[],plays:[],results:[]}}catch{return{people:[],plays:[],results:[]}}};
let db=load();
function persist(){localStorage.setItem(STORAGE_KEY,JSON.stringify(db));renderAll()}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function showNotice(message,error=false){const n=$('playNotice');n.hidden=false;n.className='notice'+(error?' error':'');n.textContent=message}
function selectTab(id){document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===id));document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id===id))}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>selectTab(b.dataset.tab)));
$('personForm').addEventListener('submit',e=>{e.preventDefault();const name=$('personName').value.trim();if(!name)return;if(db.people.some(p=>p.name.toLowerCase()===name.toLowerCase())){alert('Esa persona ya está registrada.');return}db.people.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),name});$('personName').value='';persist()});
$('playForm').addEventListener('submit',e=>{e.preventDefault();const person=db.people.find(p=>p.id===$('personSelect').value);const modality=$('modalidad').value;const raw=$('numero').value.trim().toLowerCase().replace(/\s/g,'');const amount=Number($('monto').value);const conCorrido=modality==='fijo'&&$('conCorrido').checked;if(!person){showNotice('Primero registra y selecciona una persona.',true);return}let number=raw;if(modality==='fijo'){if(!/^\d{2}$/.test(raw)){showNotice('El fijo debe tener exactamente dos cifras, por ejemplo 19.',true);return}}else{if(/^\d{4}$/.test(raw))number=raw.slice(0,2)+'x'+raw.slice(2);if(!/^\d{2}x\d{2}$/.test(number)){showNotice('El parlet debe tener cuatro cifras, por ejemplo 5878, o formato 45x56.',true);return}const parts=number.split('x');number=parts.join('x')}
if(!(amount>0)){showNotice('Introduce un importe mayor que cero.',true);return}const parts=number.split('x');const canonical=modality==='parlet'?parts.slice().sort().join('x'):number;
db.plays.push({id:Date.now().toString()+Math.random().toString(16).slice(2),personId:person.id,person:person.name,turn:$('turno').value,modality,number,canonical,amount,conCorrido,date:today(),createdAt:new Date().toISOString()});$('numero').value='';$('monto').value='';$('conCorrido').checked=false;showNotice('Jugada guardada correctamente.');persist()});
$('modalidad').addEventListener('change',()=>{const fixed=$('modalidad').value==='fijo';$('numHelp').textContent=fixed?'Fijo: escribe exactamente dos cifras.':'Parlet: escribe cuatro cifras seguidas (por ejemplo 5878) y la x se pondrá automáticamente; también puedes escribir 58x78.';$('numero').placeholder=fixed?'Ej. 19':'Ej. 5878 o 58x78';$('corridaWrap').hidden=!fixed;$('conCorrido').checked=false});
$('numero').addEventListener('input',()=>{if($('modalidad').value!=='parlet')return;const input=$('numero');const raw=input.value.trim();if(/^\d{4}$/.test(raw)){input.value=raw.slice(0,2)+'x'+raw.slice(2)}});
function parseBulkLine(line){
  let text=line.trim().replace(/^[•*]+\s*/,'');
  if(!text)return null;
  text=text.replace(/\s+/g,' ');
  const amountPattern='(\\d+(?:[.,]\\d{1,2})?)';
  const makeAmount=value=>Number(String(value).replace(',','.'));
  // P 50 expands all double pairs.
  let pm=text.match(/^P\s*(?:-|con\s*)?\(?\s*(\d+(?:[.,]\d{1,2})?)\s*\)?$/i);
  if(pm){const amount=makeAmount(pm[1]);if(!(amount>0))return {error:'Importe inválido en parejas.'};return {items:Array.from({length:10},(_,i)=>({number:String(i)+String(i),modality:'fijo',amount}))};}
  // 63xL90-20 expands to 63x90 through 63x99, 20 each.
  let m=text.match(/^(\d{2})\s*[x×]\s*L(\d{2})\s*-\s*(\d+(?:[.,]\d{1,2})?)$/i);
  if(m){
    const first=Number(m[2]);
    const amount=makeAmount(m[3]);
    if(!(amount>0))return {error:'El importe de «'+line.trim()+'» debe ser mayor que cero.'};
    return {items:Array.from({length:100-first},(_,i)=>({number:m[1]+'x'+String(first+i).padStart(2,'0'),modality:'parlet',amount}))};
  }
  // L20-30 expands to 20 through 29, 30 each.
  m=text.match(/^L(\d{2})\s*-\s*(\d+(?:[.,]\d{1,2})?)$/i);
  if(m){
    const first=Number(m[1]),amount=makeAmount(m[2]);
    if(first%10!==0)return {error:'En Lxx, el rango debe empezar en una decena, por ejemplo L20-30.'};
    if(!(amount>0))return {error:'El importe de «'+line.trim()+'» debe ser mayor que cero.'};
    return {items:Array.from({length:10},(_,i)=>({number:String(first+i).padStart(2,'0'),modality:'fijo',amount}))};
  }
  // T5-50 expands to 05,15,...,95, 50 each.
  m=text.match(/^T([0-9])\s*-\s*(\d+(?:[.,]\d{1,2})?)$/i);
  if(m){
    const digit=m[1],amount=makeAmount(m[2]);
    if(!(amount>0))return {error:'El importe de «'+line.trim()+'» debe ser mayor que cero.'};
    return {items:Array.from({length:10},(_,i)=>({number:String(i)+digit,modality:'fijo',amount}))};
  }
  // Individual play: 08x20-1030, 58x78 con 50, 50 100, 19(50).
  const re=new RegExp('^(\\d{2}(?:\\s*[x×]\\s*\\d{2})?)\\s*(?:-\\s*|(?:con\\s*)?)(?:\\(\\s*'+amountPattern+'\\s*\\)|'+amountPattern+')$','i');
  m=text.match(re);
  if(!m)return {error:'No pude reconocer «'+line.trim()+'». Usa 08×20-1030, 58x78 con 50, 50 100, L20-30, T5-50 o 63×L90-20.'};
  const rawNumber=m[1].replace(/\s/g,'').toLowerCase().replace('×','x');
  const amount=makeAmount(m[2]||m[3]);
  if(!(amount>0))return {error:'El importe de «'+line.trim()+'» debe ser mayor que cero.'};
  const isParlet=rawNumber.includes('x');
  return {items:[{number:rawNumber,modality:isParlet?'parlet':'fijo',amount}]};
}

$('importPlays').addEventListener('click',()=>{
  const person=db.people.find(p=>p.id===$('personSelect').value);
  const notice=$('bulkNotice');
  const showBulk=(msg,error=false)=>{notice.hidden=false;notice.className='notice'+(error?' error':'');notice.textContent=msg};
  if(!person){showBulk('Primero selecciona una persona en el campo Persona.',true);return}
  const rawText=$('bulkPlays').value.trim();
  if(!rawText){showBulk('Pega primero una o varias jugadas.',true);return}
  const lines=rawText.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  const parsed=[];const errors=[];
  lines.forEach((line,i)=>{const result=parseBulkLine(line);if(!result) return;if(result.error)errors.push('Línea '+(i+1)+': '+result.error);else parsed.push(...result.items)});
  if(errors.length){showBulk(errors.join(' '),true);return}
  if(!parsed.length){showBulk('No encontré jugadas válidas. Escribe una jugada por línea.',true);return}
  const date=today(),turn=$('turno').value,conCorrido=$('conCorrido').checked;
  let saved=0;
  for(const item of parsed){
    let number=item.number;
    if(item.modality==='parlet'){
      if(!/^\d{2}x\d{2}$/.test(number)){showBulk('Parlet inválido: '+number+'. Usa dos cifras x dos cifras.',true);return}
      const parts=number.split('x'),canonical=parts.slice().sort().join('x');
      // Cada línea es una jugada independiente: no se eliminan repetidos, ni aunque
      // coincidan número, importe o parlet invertido.
      db.plays.push({id:Date.now().toString()+Math.random().toString(16).slice(2),personId:person.id,person:person.name,turn,modality:'parlet',number,canonical,amount:item.amount,conCorrido:false,date,createdAt:new Date().toISOString()});saved++;
    }else{ 
      if(!/^\d{2}$/.test(number)){showBulk('Fijo inválido: '+number+'. Usa exactamente dos cifras.',true);return}
      db.plays.push({id:Date.now().toString()+Math.random().toString(16).slice(2),personId:person.id,person:person.name,turn,modality:'fijo',number,canonical:number,amount:item.amount,conCorrido,date,createdAt:new Date().toISOString()});saved++;
    }
  }
  if(saved){$('bulkPlays').value='';persist()}
  showBulk('Se guardaron '+saved+' jugadas. Se conservaron todas las líneas, incluidos los números y parlets repetidos.');
});
$('resultDate').value=today();$('exportDate').value=today();
function prizeFor(p){if(p.modality==='parlet')return p.amount*1000;const result=db.results.find(r=>r.date===p.date&&r.turn===p.turn);if(!result)return p.amount*(p.conCorrido?70:80);const b=resultBreakdown(result.digits);let prize=0;if(p.number===b.fixed)prize+=p.amount*(p.conCorrido?70:80);if(p.conCorrido){if(p.number===b.corrido1)prize+=p.amount*4;if(p.number===b.corrido2)prize+=p.amount*4}return prize}
function resultBreakdown(d){return {centena:d[0],fixed:d.slice(1,3),corrido1:d.slice(3,5),corrido2:d.slice(5,7)}}
function renderPeople(){$('personSelect').innerHTML='<option value="">Selecciona una persona</option>'+db.people.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');$('peopleList').innerHTML=db.people.length?db.people.map(p=>`<div class="item"><button class="person-name" data-person-detail="${esc(p.id)}">${esc(p.name)}</button><div class="detail"><small>${db.plays.filter(x=>x.personId===p.id).length} jugadas</small></div><button class="delete" data-del-person="${esc(p.id)}">Eliminar</button></div>`).join(''):'<p class="muted">Todavía no hay personas registradas.</p>';document.querySelectorAll('[data-person-detail]').forEach(b=>b.onclick=()=>renderPersonDetail(b.dataset.personDetail));document.querySelectorAll('[data-del-person]').forEach(b=>b.onclick=()=>{const id=b.dataset.delPerson;if(confirm('¿Eliminar esta persona y todas sus jugadas?')){db.people=db.people.filter(p=>p.id!==id);db.plays=db.plays.filter(p=>p.personId!==id);$('personDetail').innerHTML='';persist()}})}
function renderPersonDetail(id){const person=db.people.find(p=>p.id===id);if(!person)return;const plays=db.plays.filter(p=>p.personId===id);const groups={};plays.forEach(p=>{const k=p.date+'|'+p.turn;(groups[k]??=[]).push(p)});$('personDetail').innerHTML=`<div class="person-history"><h3>Historial: ${esc(person.name)}</h3>${Object.keys(groups).length?Object.keys(groups).sort().reverse().map(k=>{const ps=groups[k];return `<div class="history-group"><strong>${esc(k.split('|')[0])} · ${esc(k.split('|')[1])}</strong>${ps.map(p=>`<div class="playline">${p.modality==='fijo'?'Fijo':'Parlet'} ${esc(p.number)}${p.conCorrido?' (con corrido)':''} — ${money(p.amount)}</div>`).join('')}<b>Total del registro: ${money(ps.reduce((s,p)=>s+p.amount,0))}</b></div>`}).join(''):'<p class="muted">Esta persona aún no tiene jugadas.</p>'}</div>`}
function renderResults(){$('resultList').innerHTML=''}
function renderAll(){renderPeople();renderResults();renderTodayTotals()}
function renderTodayTotals(){const total=db.plays.filter(p=>p.date===today()).reduce((s,p)=>s+Number(p.amount||0),0);const ten=total*0.10;$('todayPlayed').textContent=money(total);$('todayProfit').textContent=money(ten);$('todayDeliver').textContent=money(total-ten)}
function resultBreakdown(d){return {centena:d[0],fixed:d.slice(1,3),corrido1:d.slice(3,5),corrido2:d.slice(5,7)}}
function findWinners(d,turn,date){const b=resultBreakdown(d),out=[];db.plays.filter(p=>p.turn===turn&&p.date===date).forEach(p=>{let prize=0,why=[];if(p.modality==='fijo'){if(p.number===b.fixed){prize+=p.amount*(p.conCorrido?70:80);why.push('fijo')}if(p.conCorrido&&p.number===b.corrido1){prize+=p.amount*4;why.push('primer corrido')}if(p.conCorrido&&p.number===b.corrido2){prize+=p.amount*4;why.push('segundo corrido')}}else{const pair=p.number.split('x');if(pair.length===2&&pair[0]===pair[1]&&pair[0]===b.fixed){prize=p.amount*1000;why.push('parlet')}}if(prize>0)out.push({p,prize,why:why.join(' + ')})});return out}
function normalizeResult(v){return v.replace(/\s/g,'').replace(/\D/g,'')}
$('resultDigits').addEventListener('input',()=>{const d=normalizeResult($('resultDigits').value).slice(0,7);$('resultDigits').value=d.length>3?d.slice(0,3)+' '+d.slice(3):d});
$('breakdownBtn').addEventListener('click',()=>{const d=normalizeResult($('resultDigits').value);if(!/^\d{7}$/.test(d)){alert('Escribe siete dígitos: 122 8810.');return}const date=$('resultDate').value||today(),turn=$('resultTurn').value;db.results=db.results.filter(r=>!(r.date===date&&r.turn===turn));db.results.push({id:String(Date.now()),digits:d,turn,date});persist();const wins=findWinners(d,turn,date);$('breakdown').innerHTML='<p><strong>Tiro: '+d.slice(0,3)+' '+d.slice(3)+'</strong></p>'+(wins.length?'<h3>Ganadores e importe de cada uno</h3>'+wins.map(w=>'<div class="item"><div class="detail"><strong>'+esc(w.p.person)+' · '+esc(w.p.modality==='fijo'?'Fijo':'Parlet')+' '+esc(w.p.number)+'</strong><small>'+esc(w.why)+'</small></div><strong>'+money(w.prize)+'</strong></div>').join(''):'<p class="muted">No hay ganadores para este tiro en el turno y fecha elegidos.</p>')});
$('takePhotoBtn').addEventListener('click',()=> $('playsPhoto').click());
$('playsPhoto').addEventListener('change',()=>{const f=$('playsPhoto').files&&$('playsPhoto').files[0];if(!f)return;const box=$('photoPreview');box.hidden=false;box.innerHTML='<p class="muted">Foto tomada. Revisa la imagen y transcribe o corrige las jugadas abajo antes de guardarlas.</p>';const img=document.createElement('img');img.alt='Foto de las jugadas';img.src=URL.createObjectURL(f);img.style='width:100%;max-height:320px;object-fit:contain;border-radius:10px';box.appendChild(img)});
$('exportBtn').addEventListener('click',()=>{const rows=[['fecha','turno','modalidad','numero','importe','con_corrido'],...db.plays.map(p=>[p.date,p.turn,p.modality==='fijo'?'Fijo':'Parlet',p.number,p.amount,p.conCorrido?'Sí':'No'])];const csv=rows.map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8;'}));a.download='bolita-historial.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)});
function shareText(turn){const date=$('exportDate').value||today();const plays=db.plays.filter(p=>p.date===date&&p.turn===turn);const lines=[`BOLITA — ${turn.toUpperCase()}`,`Fecha: ${date.replaceAll('-','/')}`,''];if(!plays.length){lines.push('No hay jugadas registradas para este turno.')}else{const fixed=plays.filter(p=>p.modality==='fijo'),parlets=plays.filter(p=>p.modality==='parlet');if(fixed.length){lines.push('FIJOS');fixed.forEach(p=>lines.push(`${p.number} — ${money(p.amount)}${p.conCorrido?' (con corrido)':' (sin corrido)'}`));lines.push('')}if(parlets.length){lines.push('PARLETS');parlets.forEach(p=>lines.push(`${p.number} — ${money(p.amount)}`));lines.push('')}lines.push(`TOTAL JUGADO: ${money(plays.reduce((s,p)=>s+p.amount,0))}`)}return lines.join('\n')}
async function shareTurn(turn){const txt=shareText(turn);$('sharePreview').value=txt;$('shareNotice').hidden=true;try{if(navigator.share){await navigator.share({title:`Bolita ${turn}`,text:txt});}else if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(txt);$('shareNotice').hidden=false;$('shareNotice').textContent='Texto copiado. Pégalo en WhatsApp.';}else{$('shareNotice').hidden=false;$('shareNotice').textContent='El texto está preparado arriba. Mantén pulsado para copiarlo y enviarlo por WhatsApp.'}}catch(err){if(err.name!=='AbortError'){$('shareNotice').hidden=false;$('shareNotice').textContent='El texto está preparado arriba para copiarlo y enviarlo.'}}}
$('shareMidday').addEventListener('click',()=>shareTurn('Mediodía'));$('shareNight').addEventListener('click',()=>shareTurn('Noche'));$('copyShare').addEventListener('click',async()=>{const txt=$('sharePreview').value;if(!txt){$('shareNotice').hidden=false;$('shareNotice').textContent='Primero selecciona Mediodía o Noche.';return}try{await navigator.clipboard.writeText(txt);$('shareNotice').textContent='Texto copiado. Ya puedes pegarlo en WhatsApp.'}catch{$('sharePreview').focus();$('sharePreview').select();$('shareNotice').textContent='Texto seleccionado. Mantén pulsado y elige Copiar.'}$('shareNotice').hidden=false});
renderAll();
